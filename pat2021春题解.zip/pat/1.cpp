#include<bits/stdc++.h>
using namespace std;
ifstream fin("pat/in.txt");
ofstream fout("pat/out.txt");
#define cin fin
#define cout fout

int n,MAXP;
bool isPrime[100000]={0};
vector<int>primes;

//筛法选出所有质数
void checkPrime(){
    primes.push_back(2);
    isPrime[2]=true;
    //先假定所有奇数为质数
    for(int i=3;i<=MAXP;i+=2){
        isPrime[i]=true;
    }
    //从小到大，挨个探查，如果是质数，将其所有倍数（不含自己）置为合数
    for(int i=3;i<=MAXP;i+=2){
        if(isPrime[i]){
            primes.push_back(i);
            for(int j=i*2;j<=MAXP;j+=i){
                isPrime[j]=false;
            }
        }
    }
    //将所有质数按从大到小排
    reverse(primes.begin(),primes.end());
}

bool checkAP(int p,int unit){
    int count=0;
    for(int cur=p;cur>0&&isPrime[cur];cur-=unit)count++;
    return count>=n;
}

int main(){
    cin>>n>>MAXP;
    checkPrime();
    if(n==1)return primes[0];
    //令range为等差数列最大值和最小值的差，则其必为(n-1)的倍数
    for(int range=100010-100010%(n-1);range>0;range-=(n-1)){
        int unit=range/(n-1);
        //对质数表中的所有数，检查其能否作为等差数列最大项
        for(int p:primes){
            if(p<range)break;
            if(checkAP(p,unit)){
                for(int i=p-(n-1)*unit;i<=p;i+=unit){
                    cout<<i<<(i==p?'\n':' ');
                }
                return 0;
            }
        }
    }
    cout<<primes[0];
    return 0;
}