#include<bits/stdc++.h>
using namespace std;
ifstream fin("pat/in.txt");
ofstream fout("pat/out.txt");
#define cin fin
#define cout fout

int N;
pair<int,int>visitor[2000];
//dp[i]表示i时刻（单位秒）有个人离开，则此时有多少人曾来过
int dp[86400]={0};
//maxbefore[i]为dp数组的前缀最大值
int maxbefore[86400]={0};

int main(){
    cin>>N;
    for(int i=0;i<N;i++){
        int hh,mm,ss;
        char tmp;
        cin>>hh>>tmp>>mm>>tmp>>ss;
        visitor[i].first=hh*3600+mm*60+ss;
        cin>>hh>>tmp>>mm>>tmp>>ss;
        visitor[i].second=hh*3600+mm*60+ss;
    }
    //按照来的时间进行排序
    sort(visitor,visitor+N);
    int curtime=0;
    for(int i=0;i<N;i++){
        auto [cometime,leavetime]=visitor[i];
        //推进前缀最大值的下标
        while(curtime<cometime){
            ++curtime;
            maxbefore[curtime]=max(maxbefore[curtime-1],dp[curtime]);
        }
        //根据cometime之前的最大值，加一，获取leavetime时的值
        dp[leavetime]=max(dp[leavetime],maxbefore[curtime]+1);
    }
    while(++curtime<86400){
        maxbefore[curtime]=max(maxbefore[curtime-1],dp[curtime]);
    }
    cout<<maxbefore[86399];
    return 0;
}