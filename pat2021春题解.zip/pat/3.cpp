#include<bits/stdc++.h>
using namespace std;
ifstream fin("pat/in.txt");
ofstream fout("pat/out.txt");
#define cin fin
#define cout fout

int N,M;
int Data[1001];
unordered_map<int,int>Pos;
int Size=0;

//插入一个键值，先放到堆尾，再伺机把比自己小的父结点拉下来，自己爬上去
void insert(int key){
    Data[++Size]=key;
    Pos[key]=Size;
    for(int cur=Size;cur>1;){
        int parent=cur/2;
        if(Data[parent]<Data[cur]){
            swap(Data[parent],Data[cur]);
            swap(Pos[Data[parent]],Pos[Data[cur]]);
            cur=parent;
        }
        else break;
    }
}

int main(){
    cin>>N>>M;
    for(int i=0;i<N;i++){
        int key;
        cin>>key;
        insert(key);
    }
    cin.get();
    for(int i=0;i<M;i++){
        string line;
        getline(cin,line);
        if(line.back()=='t'){
            int j=line.find_first_of(' ');
            int x=stoi(line.substr(0,j));
            if(Pos.count(x)&&Pos[x]==1)cout<<"1";
            else cout<<"0";
        }
        else if(line.back()=='s'){
            int j=line.find_first_of(' ');
            int x=stoi(line.substr(0,j));
            int k=line.find_first_of(' ',j+5);
            int y=stoi(line.substr(j+5,k-j-5));
            if(x!=y&&Pos.count(x)&&Pos.count(y)&&Pos[x]/2==Pos[y]/2)cout<<"1";
            else cout<<"0";
        }
        else{
            int j=line.find_first_of(' ');
            int x=stoi(line.substr(0,j));
            if(line[j+8]=='p'){
                int y=stoi(line.substr(j+18));
                if(x!=y&&Pos.count(x)&&Pos.count(y)&&Pos[x]==Pos[y]/2)cout<<"1";
                else cout<<"0";
            }
            else if(line[j+8]=='l'){
                int y=stoi(line.substr(j+22));
                if(x!=y&&Pos.count(x)&&Pos.count(y)&&Pos[x]==Pos[y]*2)cout<<"1";
                else cout<<"0";
            }
            else{
                int y=stoi(line.substr(j+23));
                if(x!=y&&Pos.count(x)&&Pos.count(y)&&Pos[x]==Pos[y]*2+1)cout<<"1";
                else cout<<"0";
            }
        }
    }
}